package command;

public class GoodsOrderCommand {
	String purchTotal;
	String prodNums;
	String purchAddr;
	String purchReceiver;
	String purchPhoneNumber;
	String purchMsg;
	public String getPurchTotal() {
		return purchTotal;
	}
	public void setPurchTotal(String purchTotal) {
		this.purchTotal = purchTotal;
	}
	public String getProdNums() {
		return prodNums;
	}
	public void setProdNums(String prodNums) {
		this.prodNums = prodNums;
	}
	public String getPurchAddr() {
		return purchAddr;
	}
	public void setPurchAddr(String purchAddr) {
		this.purchAddr = purchAddr;
	}
	public String getPurchReceiver() {
		return purchReceiver;
	}
	public void setPurchReceiver(String purchReceiver) {
		this.purchReceiver = purchReceiver;
	}
	public String getPurchPhoneNumber() {
		return purchPhoneNumber;
	}
	public void setPurchPhoneNumber(String purchPhoneNumber) {
		this.purchPhoneNumber = purchPhoneNumber;
	}
	public String getPurchMsg() {
		return purchMsg;
	}
	public void setPurchMsg(String purchMsg) {
		this.purchMsg = purchMsg;
	}
}
