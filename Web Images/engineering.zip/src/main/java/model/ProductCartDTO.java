package model;

public class ProductCartDTO {
	ProductDTO productDTO;
	CartDTO cartDTO;
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public CartDTO getCartDTO() {
		return cartDTO;
	}
	public void setCsrtDTO(CartDTO cartDTO) {
		this.cartDTO = cartDTO;
	}
}
