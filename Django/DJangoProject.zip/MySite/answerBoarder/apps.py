from django.apps import AppConfig


class AnswerboarderConfig(AppConfig):
    name = 'answerBoarder'
