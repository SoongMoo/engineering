from django.db import models
from member.models import Member
from django.core.validators import MinLengthValidator

# Create your models here.
from datetime import datetime

class Board(models.Model):
    
    pw_validator = MinLengthValidator(8, "8자 이상이어야 합니다.")
    BOARD_NUM = models.BigAutoField(blank=False, null=False, primary_key=True)# 글번호
    USER_ID =  models.ForeignKey(Member, on_delete=models.CASCADE)  # 글쓴이의 아이디
    ### 글쓴 아이디가 삭제가 되면  이 아이디가 쓴 글은 모두 삭제
    BOARD_NAME = models.CharField(max_length=20, blank=False, null=False) # 글쓴이
    BOARD_PASS = models.CharField(max_length=200, blank=False, null=False, 
                                  validators=[pw_validator]) # 글을 수정 할 때 사용할 비밀번호
    BOARD_SUBJECT  = models.CharField(max_length=50, blank=False, null=False)# 글제목
    BOARD_CONTENT = models.CharField(max_length=2000, blank=True, null=True)# 글 내용
    BOARD_READCOUNT = models.DecimalField(max_digits= 6, decimal_places= 0, 
                                default = 0, blank=False, null=False)# 방문자 수
    BOARD_DATE = models.DateTimeField(blank=False, null=False, default=datetime.now) # 등록일
    class Meta:
        db_table = "BOARDER"