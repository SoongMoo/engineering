import math
import os

from django.core.paginator import Paginator
from django.db.models import Max
from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.template.context_processors import request
from django.views.decorators.csrf import csrf_exempt

from member.models import Member
from member.views import pwEncrypt

from .forms import BoardWriteForm
from .models import Board


#### 
# Create your views here.
def boardDelete(request):
    boardNum = request.GET['BOARD_NUM']
    board = Board.objects.get(BOARD_NUM = boardNum);
    board.delete()
    return HttpResponseRedirect("boardList")
def boardModifyPro(request):
    boardNum = request.POST['BOARD_NUM']
    board = Board.objects.get(BOARD_NUM = boardNum);
    if request.method == 'POST':
        board.BOARD_NAME = request.POST['BOARD_NAME']
        board.BOARD_SUBJECT = request.POST['BOARD_SUBJECT']
        board.BOARD_CONTENT = request.POST['BOARD_CONTENT']
        board.save()
        return HttpResponseRedirect("BoarderDetail?BOARD_NUM=" + boardNum)
    else:
        context = {"board" : board}
        return render(request, "board/boardModify.html", context)

def BoardModify(request):
    boardNum = request.GET['BOARD_NUM']
    board = Board.objects.get(BOARD_NUM = boardNum)
    context = {'board': board}
    return render(request, "board/boardModify.html", context)

def BoarderDetail(request):
    boardNum = request.GET['BOARD_NUM']
    board = Board.objects.get(BOARD_NUM = boardNum)
    board.BOARD_READCOUNT += 1
    board.save()
    context = {'board': board}
    return render(request, "board/boardDetail.html", context)

def boardList(request):
    ### select * from boarder order by BOARD_NUM desc
    board = Board.objects.all().order_by('-BOARD_NUM')
    
    ################ paging #############
    page = request.GET.get('page',1)
    limit = 5
    page_range = 10 
    paginator = Paginator(board ,limit )
    contacts = paginator.get_page(page)
    current_block = math.ceil(int(page)/page_range)
    start_block = (current_block -1) * page_range #  0, 10 , 20
    end_block = start_block + page_range
    p_range = paginator.page_range[start_block:end_block]
    context = {'contacts':contacts,'p_range':p_range}
    ################ paging #############
    
    return render(request, "board/boardList.html", context)

def boardWrite(request):
    return render(request, "board/boardForm.html",{'f':BoardWriteForm()})

@csrf_exempt
def boardWritePro(request):
    member = Member.objects.get(USER_ID=request.session['member']['USER_ID'])
    boarderNum = Board.objects.aggregate(BOARD_NUM = Max('BOARD_NUM'))
              # select max(BOARD_NUM) from boarder;
    if boarderNum['BOARD_NUM'] is None:
        boarderNum['BOARD_NUM'] = 1
    else :
        boarderNum['BOARD_NUM'] += 1
    form = BoardWriteForm(request.POST)
    if request.method == 'POST':   
        if  form.is_valid():
            board = Board()
            board.BOARD_CONTENT = request.POST['BOARD_CONTENT']
            board.BOARD_NAME = request.POST['BOARD_NAME']
            board.BOARD_NUM = boarderNum['BOARD_NUM']
            board.BOARD_PASS = pwEncrypt(request.POST['BOARD_PASS'])
            board.BOARD_SUBJECT = request.POST['BOARD_SUBJECT']
            board.USER_ID = member ###foreign key컬럼은 값을 직접 대입할 수 없다.
            board.save() # 디비에 저장
            return HttpResponseRedirect("boardList")
        else:
            return render(request, "board/boardForm.html", {'f':form,'error':'비밀번호는 8자리 이상입니다.'})
    else:
        return render(request, "board/boardForm.html", {'f':form,'error':'저장되지 않았습니다.'})
    
    