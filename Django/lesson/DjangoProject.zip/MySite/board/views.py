from django.db.models import Max
from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.template.context_processors import request
from django.views.decorators.csrf import csrf_exempt

import os
from member.models import Member
from member.views import pwEncrypt

from .forms import BoardWriteForm
from .models import Board


# Create your views here.
def boardList(request):
    return render(request, "board/boardList.html")

def boardWrite(request):
    return render(request, "board/boardForm.html",{'f':BoardWriteForm()})

@csrf_exempt
def boardWritePro(request):
    member = Member.objects.get(USER_ID=request.session['member']['USER_ID'])
    boarderNum = Board.objects.aggregate(BOARD_NUM = Max('BOARD_NUM'))
    if boarderNum['BOARD_NUM'] is None:
        boarderNum['BOARD_NUM'] = 1
    else :
        boarderNum['BOARD_NUM'] += 1
    if request.method == 'POST':    
        board = Board()
        board.BOARD_CONTENT = request.POST['BOARD_CONTENT']
        board.BOARD_NAME = request.POST['BOARD_NAME']
        board.BOARD_NUM = boarderNum['BOARD_NUM']
        board.BOARD_PASS = pwEncrypt(request.POST['BOARD_PASS'])
        board.BOARD_SUBJECT = request.POST['BOARD_SUBJECT']
        board.USER_ID = member ###foreign key컬럼은 값을 직접 대입할 수 없다.
        board.save()
        return HttpResponseRedirect("boardList")
    else:
        return HttpResponseRedirect("boardWrite")
    
    