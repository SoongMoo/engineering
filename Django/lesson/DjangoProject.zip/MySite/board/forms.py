from django.forms import ModelForm

from .models import Board
from django import forms
from django.utils.translation import gettext as _

class BoardWriteForm(ModelForm):
    class Meta:
        model = Board
        widgets = {'BOARD_PASS':forms.PasswordInput, 'BOARD_CONTENT' : forms.Textarea}
        fields = ['BOARD_NAME', 'BOARD_SUBJECT', 'BOARD_CONTENT', 'BOARD_PASS']
        labels = {
            'BOARD_NAME': _('글쓴이'),
            'BOARD_SUBJECT': _('글 제목'),
            'BOARD_CONTENT': _('글 내용'),
            'BOARD_PASS': _('비밀번호'),
            } 