from django.conf.urls import url 
from django.urls import path
from . import views

app_name = 'board'
urlpatterns = [
    url('boardDelete', views.boardDelete),
    url('boardModifyPro', views.boardModifyPro),
    url('BoardModify', views.BoardModify),
    url('BoarderDetail', views.BoarderDetail),
    url('boardWritePro', views.boardWritePro),
    url('boardWrite', views.boardWrite),
    url('boardList', views.boardList),
]
