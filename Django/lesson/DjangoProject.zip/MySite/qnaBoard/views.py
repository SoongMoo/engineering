import math

from django.core.paginator import Paginator
from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from member.models import Member

from .forms import QnaBoardWriteForm
from .models import QnaBoard


# Create your views here.
def qnaBoardDeletePro(request):
    qnaNum = request.GET['QNA_NUM']
    qnaBoard = QnaBoard.objects.get(QNA_NUM = qnaNum)
    qnaBoard.delete()
    return HttpResponseRedirect("qnaList")

@csrf_exempt
def qnaBoardUpdatePro(request):
    qnaNum = request.POST['QNA_NUM']
    qnaBoard = QnaBoard.objects.get(QNA_NUM = qnaNum)
    if request.method == 'POST':
        qnaBoard.QNA_SUBJECT = request.POST['QNA_SUBJECT']
        qnaBoard.QNA_CONTENT = request.POST['QNA_CONTENT']
        qnaBoard.save()
        return HttpResponseRedirect("qnaDetail?QNA_NUM="+qnaNum)
    else:
        return render(request, "qnaBoard/qnaBoardModify.html",{'qnaBoard':qnaBoard})

def qnaBoardUpdate(request):
    qnaNum = request.GET['QNA_NUM']
    qnaBoard = QnaBoard.objects.get(QNA_NUM = qnaNum)
    return render(request, "qnaBoard/qnaBoardModify.html",{'qnaBoard':qnaBoard})
 
def qnaBoardDetail(request):
    qnaNum = request.GET['QNA_NUM']
    qnaBoard = QnaBoard.objects.get(QNA_NUM = qnaNum)
    qnaBoard.QNA_READCOUNT += 1
    qnaBoard.save()
    return render(request, "qnaBoard/qnaBoardDetail.html",{'qnaBoard':qnaBoard})

def qnaList(request):
    qnaBoards = QnaBoard.objects.all().order_by('-QNA_NUM')
    
    ################ paging #############
    page = request.GET.get('page',1)
    limit = 5
    page_range = 10 
    paginator = Paginator(qnaBoards,limit )
    contacts = paginator.get_page(page)
    current_block = math.ceil(int(page)/page_range)
    start_block = (current_block -1) * page_range #  0, 10 , 20
    end_block = start_block + page_range
    p_range = paginator.page_range[start_block:end_block]
    context = {'contacts':contacts,'p_range':p_range}
    ################ paging #############
    
    return render(request, "qnaBoard/qnaBoardList.html",context)

def qnaBoardWrite(request):
    return render(request, "qnaBoard/qnaBoardRegist.html",{'f':QnaBoardWriteForm()})

@csrf_exempt
def qnaBoardWritePro(request):
    member = Member.objects.get(USER_ID = request.session['member']['USER_ID'])
    form = QnaBoardWriteForm(request.POST)
    if request.method == 'POST':
        qnaBoard = QnaBoard()
        qnaBoard.QNA_CONTENT = request.POST['QNA_CONTENT']
        qnaBoard.QNA_SUBJECT = request.POST['QNA_SUBJECT']
        qnaBoard.USER_ID = member
        qnaBoard.save()
        return HttpResponseRedirect("qnaList")
    else:
        context = {'f':form}
        return render(request, "qnaBoard/qnaBoardRegist.html",context)
    