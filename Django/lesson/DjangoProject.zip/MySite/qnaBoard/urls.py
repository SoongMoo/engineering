from django.contrib import admin
from django.urls import path, include

from . import views

urlpatterns = [
    
    path('qnaDelete', views.qnaBoardDeletePro),
    path('qnaUpdateAction', views.qnaBoardUpdatePro),
    path('qnaUpdate', views.qnaBoardUpdate),
    path('qnaDetail', views.qnaBoardDetail),
    path('qnaCreateAction', views.qnaBoardWritePro),
    path('qnaWrite', views.qnaBoardWrite),
    path('qnaList', views.qnaList),
]
