from django.apps import AppConfig


class QnaboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'qnaBoard'
