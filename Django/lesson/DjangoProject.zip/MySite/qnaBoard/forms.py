from django import forms
from django.forms.models import ModelForm

from .models import QnaBoard
from django.utils.translation import gettext as _

class QnaBoardWriteForm(ModelForm):
    class Meta:
        model = QnaBoard
        widgets = {'QNA_CONTENT' : forms.Textarea}
        fields = ['QNA_SUBJECT','QNA_CONTENT']
        labels = {
            'QNA_SUBJECT' : _('제목'),
            'QNA_CONTENT' : _('내용'),
            }