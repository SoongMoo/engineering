from datetime import datetime

from django.db import models

from member.models import Member


# Create your models here.
class QnaBoard(models.Model):
    ### QNABOARD테이블에 들어 갈 컬럼들을 정의 
    USER_ID = models.ForeignKey(Member, on_delete=models.SET_NULL, null=True)
    QNA_NUM = models.BigAutoField(blank=False, null=False, primary_key=True)
    QNA_SUBJECT = models.CharField(max_length=50, blank=False, null=False)
    QNA_CONTENT = models.CharField(max_length=2000, blank=False, null=False)
    QNA_READCOUNT = models.DecimalField(max_digits=6, decimal_places= 0, default= 0,
                                          blank=False, null=False )
    QNA_DATE = models.DateTimeField(blank=False, null=False, default=datetime.now)
    class Meta:
        db_table = 'QNABOARD'