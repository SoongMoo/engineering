from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from member.views import pwEncrypt
from member.models import Member

from .forms import NoticeWriteForm
from .models import Notice


# Create your views here.

def noticeDetail(request):
    noticeNum = request.GET['NOTICE_NUM']
    notice = Notice.objects.get(NOTICE_NUM = noticeNum)
    notice.NOTICE_READCOUNT += 1
    notice.save()
    context =  {'notice':notice}
    return render(request, "notice/noticeDetail.html", context)
    pass

def noticeList(request):
    notice = Notice.objects.all().order_by("-NOTICE_NUM")
    context = {"notices":notice}
    return render(request, "notice/noticeList.html",context)

def noticeWrite(request):
    return render(request, "notice/noticeWrite.html",{'f':NoticeWriteForm()})

@csrf_exempt
def noticeWritePro(request):
    member = Member.objects.get(USER_ID=request.session['member']['USER_ID'])
    
    form = NoticeWriteForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            notice = Notice();
            notice.NOTICE_CONTENT = request.POST['NOTICE_CONTENT']
            notice.NOTICE_PASS = pwEncrypt(request.POST['NOTICE_PASS'])
            notice.NOTICE_SUBJECT = request.POST['NOTICE_SUBJECT']
            notice.USER_ID = member
            notice.save()
            return HttpResponseRedirect("noticeList")
        else:
            return render(request, "notice/noticeWrite.html",{'f':form,'error':'비밀번호는 8자입니다.'})
    else:
        return render(request, "notice/noticeWrite.html",{'f':form,'error':'저장되지 않았습니다.'})
    







