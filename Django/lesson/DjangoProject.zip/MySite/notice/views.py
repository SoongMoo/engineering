from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from member.views import pwEncrypt
from member.models import Member

from .forms import NoticeWriteForm
from .models import Notice


# Create your views here.
def noticeDelete(request):
    NOTICE_NUM = request.GET['NOTICE_NUM']
    NOTICE_PASS = request.GET['NOTICE_PASS']
    notice = Notice.objects.get(NOTICE_NUM = NOTICE_NUM)
    if notice.NOTICE_PASS == pwEncrypt(NOTICE_PASS):
        notice.delete()
        return HttpResponseRedirect("noticeList")
    else:
        context = {'notice':notice, 'error':'비밀번호가 틀렸습니다.'}
        return render(request, "notice/noticeModify.html", context)
@csrf_exempt
def noticeModifyPro(request):
    NOTICE_NUM = request.POST['NOTICE_NUM']
    NOTICE_PASS = request.POST['NOTICE_PASS']
    # select * from notice where notice_num = 5;
    notice = Notice.objects.get(NOTICE_NUM = NOTICE_NUM)
    if request.method=='POST':
        if notice.NOTICE_PASS == pwEncrypt(NOTICE_PASS):
            NOTICE_SUBJECT = request.POST['NOTICE_SUBJECT']
            NOTICE_CONTENT = request.POST['NOTICE_CONTENT']
            notice.NOTICE_SUBJECT = NOTICE_SUBJECT
            notice.NOTICE_CONTENT = NOTICE_CONTENT
            notice.save()
            return HttpResponseRedirect("noticeDetail?NOTICE_NUM="+NOTICE_NUM) 
        else:
            context = {'notice':notice, 'error':'비밀번호가 틀렸습니다.'}
            return render(request, "notice/noticeModify.html", context)
    else:
        context = {'notice':notice, 'error':'저장되지 않았습니다.'}
        return render(request, "notice/noticeModify.html", context)

def noticeModify(request):
    noticeNum = request.GET['NOTICE_NUM']
            # select * from notice where notice_num = 5;
    notice = Notice.objects.get(NOTICE_NUM = noticeNum)
    context = {'notice':notice}
    return render(request, "notice/noticeModify.html", context)
    
def noticeDetail(request):
    noticeNum = request.GET['NOTICE_NUM']
    notice = Notice.objects.get(NOTICE_NUM = noticeNum)
    notice.NOTICE_READCOUNT += 1
    notice.save()
    context =  {'notice':notice}
    return render(request, "notice/noticeDetail.html", context)

def noticeList(request):
    notice = Notice.objects.all().order_by("-NOTICE_NUM")
    context = {"notices":notice}
    return render(request, "notice/noticeList.html",context)

def noticeWrite(request):
    return render(request, "notice/noticeWrite.html",{'f':NoticeWriteForm()})

@csrf_exempt
def noticeWritePro(request):
    member = Member.objects.get(USER_ID=request.session['member']['USER_ID'])
    
    form = NoticeWriteForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            notice = Notice();
            notice.NOTICE_CONTENT = request.POST['NOTICE_CONTENT']
            notice.NOTICE_PASS = pwEncrypt(request.POST['NOTICE_PASS'])
            notice.NOTICE_SUBJECT = request.POST['NOTICE_SUBJECT']
            notice.USER_ID = member
            notice.save()
            return HttpResponseRedirect("noticeList")
        else:
            return render(request, "notice/noticeWrite.html",{'f':form,'error':'비밀번호는 8자입니다.'})
    else:
        return render(request, "notice/noticeWrite.html",{'f':form,'error':'저장되지 않았습니다.'})
    







