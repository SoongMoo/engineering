from datetime import datetime

from django.core.validators import MinLengthValidator
from django.db import models
from django.template.defaultfilters import default

from member.models import Member


# Create your models here.
class Notice(models.Model):
    pw_validator = MinLengthValidator(8, "8자 이상이어야 합니다.")
    USER_ID = models.ForeignKey(Member, on_delete=models.SET_NULL,  null=True)
    NOTICE_NUM = models.BigAutoField(blank=False, null=False, primary_key=True)
    NOTICE_SUBJECT = models.CharField(max_length=50, blank=False, null=False)
    NOTICE_CONTENT = models.CharField(max_length=2000, blank=False, null=False)
    NOTICE_PASS = models.CharField(max_length=200, blank=False, null=False, validators=[pw_validator])
    NOTICE_READCOUNT = models.DecimalField(max_digits=6, decimal_places= 0, default= 0,
                                          blank=False, null=False )
    NOTICE_DATE = models.DateTimeField(blank=False, null=False, default=datetime.now)
    class Meta:
        db_table = 'NOTICE'