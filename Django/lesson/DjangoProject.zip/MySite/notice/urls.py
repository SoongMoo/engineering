from django.conf.urls import url 
from django.urls import path
from . import views

app_name = 'notice'
urlpatterns = [
    url('noticeDetail', views.noticeDetail),
    url('noticeWritePro', views.noticeWritePro),
    url('noticeWrite', views.noticeWrite),
    url('noticeList', views.noticeList),
]
