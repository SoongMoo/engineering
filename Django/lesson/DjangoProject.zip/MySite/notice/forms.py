'''
Created on 2021. 7. 27.

@author: EZEN
'''
from django.forms.models import ModelForm
from django import forms
from .models import Notice
from django.utils.translation import gettext as _

class NoticeWriteForm(ModelForm):
    class Meta:
        model = Notice
        widgets = {'NOTICE_PASS': forms.PasswordInput ,'NOTICE_CONTENT':forms.Textarea}
        fields = ['NOTICE_SUBJECT','NOTICE_CONTENT','NOTICE_PASS']
        labels = {
            'NOTICE_SUBJECT':_('제목'),
            'NOTICE_CONTENT':_('내용'),
            'NOTICE_PASS':_('비밀번호'),
            }