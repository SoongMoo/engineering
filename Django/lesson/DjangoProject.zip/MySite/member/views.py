from datetime import datetime

from django.http import HttpResponseRedirect
from django.http.response import HttpResponseNotFound
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt, csrf_protect

from .forms import SignupForm
from .models import Member

import uuid

from django.core.mail import EmailMultiAlternatives

import hashlib

from django.core.paginator import Paginator
import math

def memberDrop(request, USER_ID):
    try:
        member = Member.objects.get(USER_ID= USER_ID)
        member.delete()
        return HttpResponseRedirect("../memberlist")
    except:
        return HttpResponseRedirect("../memberlist")

@csrf_exempt
def memberUpdatePro(request):
    USER_ID = request.POST['USER_ID']
    try:
        member = Member.objects.get(USER_ID = USER_ID)
        member.USER_BIRTH = request.POST['USER_BIRTH'] 
        member.USER_EMAIL = request.POST['USER_EMAIL'] 
        member.USER_ADDR = request.POST['USER_ADDR'] 
        member.USER_PH1 = request.POST['USER_PH1'] 
        member.USER_PH2 = request.POST['USER_PH2'] 
        member.save()
        return HttpResponseRedirect("memberlist")
    except:
        print("회원이 존재하지 않습니다.")
        return HttpResponseRedirect("memberlist")

def memberUpdate(request):
    USER_ID = request.GET.get('USER_ID')
    member = Member.objects.get(USER_ID = USER_ID)
    context = {'member': member }
    return render(request, 'member/memberUpdate.html', context)

def memberInfo(request):
    USER_ID = request.GET.get('USER_ID')
    member = Member.objects.get(USER_ID = USER_ID)
    context = {'member': member }
    return render(request, 'member/memberInfo.html', context)
    
def memberDelete(request):
    return render(request, 'member/memberDelete.html')

def memberlist(request):
    page = request.GET.get('page',1) ## 쿼리스트링에 page변수가 없을 때 page는 1
    limit = 10
    page_range = 10
    members = Member.objects.all().order_by('-USER_REGIST') # order by USER_REGIST desc

    ### paging 시작
    paginator= Paginator(members, limit)
    ### 페이지 번호에 맏는 페이지 블럭 : 1page : 1번 10번, 2page: 11번 20번
    contacts = paginator.get_page(page)
    current_block = math.ceil(int(page)/page_range)
    start_block = (current_block -1) * page_range #  0, 10 , 20
    end_block = start_block + page_range          #  10, 20, 30
    ####                                   [0:10],[10:20],[20:30]    
    p_range = paginator.page_range[start_block:end_block]
    #### paging 끝
    context = {'contacts':contacts,'p_range': p_range }
    #### 페이징을 하지 않는 경우
    #context = {'members':members }
    return render(request, 'member/memberList.html', context)
@csrf_exempt
def memberDeletePro(request):
    USER_ID = request.session['member']['USER_ID']
    USER_PW = pwEncrypt(request.POST['USER_PW'])
    try:
        member = Member.objects.get(USER_ID = USER_ID, USER_PW = USER_PW)
        member.delete() # delete from member where USER_ID = 'USER_ID' and USER_PW = 'USER_PW'
        return HttpResponseRedirect("/logout")
    except:
        return render(request, 'member/memberDelete.html', {'error':'비밀번호가 틀렸습니다.'})  

def memberPasswordModifyPro(request):
    USER_ID = request.session['member']['USER_ID']
    USER_PW = pwEncrypt(request.POST['USER_PW'])
    USER_PW_NEW = request.POST['USER_PW_NEW']
    USER_PW_RE_NEW = request.POST['USER_PW_RE_NEW']
    if USER_PW_NEW != USER_PW_RE_NEW:
        return render(request, 'member/memberPasswordPro.html'
                      , {'error':'새 비밀번호와 비밀번호 확인이  다릅니다.'})
    else:
        try:
            member = Member.objects.get(USER_ID = USER_ID, USER_PW = USER_PW)
            member.USER_PW = pwEncrypt(USER_PW_NEW)
            member.save()
            return HttpResponseRedirect("memberDetail")
        except:
            return render(request, 'member/memberPasswordPro.html'
                      , {'error':'현재 비밀번호가 틀렸습니다.'})
            
def memberPasswordPro(request):
    USER_ID = request.session['member']['USER_ID']
    USER_PW = pwEncrypt(request.POST['USER_PW'])
    try:
        member = Member.objects.get(USER_ID = USER_ID, USER_PW= USER_PW)
        return render(request, 'member/memberPasswordPro.html')
    except: # 나의 정보를 가져오지 못했을 때 오류
        return render(request, 'member/memberPassword.html',{'error':'비밀번호가  틀렸습니다.'})

def changePassword(request):
    return render(request, 'member/memberPassword.html')
@csrf_exempt
def memberModifyPro(request):
    USER_ID = request.session['member']['USER_ID']
    USER_PW = pwEncrypt(request.POST['USER_PW'])
    try:
        # select * from member where USER_ID =  'USER_ID' and USER_PW = 'USER_PW'
        member = Member.objects.get(USER_ID = USER_ID, USER_PW= USER_PW)
        member.USER_BIRTH = request.POST['USER_BIRTH']
        member.USER_EMAIL = request.POST['USER_EMAIL']
        member.USER_ADDR = request.POST['USER_ADDR']
        member.USER_PH1 = request.POST['USER_PH1']
        member.USER_PH2 = request.POST['USER_PH2']
        member.save()
        return HttpResponseRedirect("memberDetail")
    except:
        return HttpResponseRedirect("memberModify?num=1")
       
def memberModify(request):
    USER_ID = request.session['member']['USER_ID']
    member = Member.objects.get(USER_ID = USER_ID)
    context = {}
    try:
        request.GET['num']
        context = {'member':member, 'error':'비밀번호가 틀립니다.'}
    except:
        context = {'member':member}
    return render(request, 'member/memberModify.html', context)

def memberDetail(request):
    USER_ID = request.session['member']['USER_ID']
    member = Member.objects.get(USER_ID = USER_ID)
    context = {'member':member}
    return render(request, 'member/memberDetail.html', context)

def pwEncrypt(USER_PW):
    result = hashlib.sha256(USER_PW.encode())
    return result.hexdigest()


def memberMail(request, USER_CK):
    USER_EMAIL = request.GET['email'] 
    # select * from member
    # where USER_EMAIL = 'highland0';
    member = Member.objects.get(USER_EMAIL = USER_EMAIL)
    try:
        if member.USER_CK == '':
            member.USER_CK = USER_CK
            member.save() # insert 
            return render(request, 'member/memberMailTrue.html')
        else:
            return render(request, 'member/memberMailFalse.html')
    except:
        pass
    
def mailSend(member):
    num = str(uuid.uuid1()).replace('-', '')
    content = "<html><body>안녕하세요 가입을 환영합니다. 아래 링크를 누르셔야만 가입이 완료됩니다.<br />"
    content += "<a href='http://localhost:8000/member/memberMail/" +num
    content += "?email="+member.USER_EMAIL+"' >클릭</a></body></html>"
    
    subject = "가입환영인사";
    from_email = 'hiland00@gmail.com'
    to = member.USER_EMAIL
    
    #### 메일을 보내기 위한 명령어 3줄
    msg = EmailMultiAlternatives(subject, content, from_email, [to]) 
    msg.attach_alternative(content, "text/html")
    msg.send() 


# Create your views here.
def agree(request):
    return render(request, 'member/agree.html')

@csrf_protect
def regist(request):
    if request.method == "GET":
        return HttpResponseRedirect("agree")
    elif request.method == "POST" :
        agree = request.POST.get("agree")
        if agree is not None :
            return render(request, 'member/memberForm.html',{'f':SignupForm()})
        else :
            return HttpResponseRedirect("agree")
        

@csrf_exempt
def memberJoinAction(request):
    if request.method == "GET":
        return HttpResponseRedirect("agree")
    elif request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            if form.cleaned_data['USER_PW']  == form.cleaned_data['USER_PW_Con']:
                member = Member()
                member.USER_ID = form.cleaned_data['USER_ID']
                member.USER_PW = pwEncrypt(form.cleaned_data['USER_PW'])
                member.USER_NAME = form.cleaned_data['USER_NAME']
                member.USER_BIRTH = form.cleaned_data['USER_BIRTH']
                member.USER_GENDER = form.cleaned_data['USER_GENDER']
                member.USER_EMAIL = form.cleaned_data['USER_EMAIL']
                member.USER_ADDR = form.cleaned_data['USER_ADDR']
                member.USER_PH1 = form.cleaned_data['USER_PH1']
                member.USER_PH2 = form.cleaned_data['USER_PH2']
                member.USER_REGIST = datetime.now()
                try: 
                    mailSend(member)
                    member.save() #  디비에 저장
                    print("저장되었습니다.")
                    return HttpResponseRedirect("/")
                except :
                   # return HttpResponseNotFound("가입되지 않았습니다.")
                    return render(request, 'member/memberForm.html',{'f':form,'error':'가입되지 않았습니다.'})    
            else :
                return render(request, 'member/memberForm.html',{'f':form,'error':'비밀번호 확인이  비밀번호와 다릅니다.'})
        else :
            return render(request, 'member/memberForm.html',{'f':form,'error':'가입되지 않았습니다.'})