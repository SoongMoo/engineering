from datetime import datetime

from django.http import HttpResponseRedirect
from django.http.response import HttpResponseNotFound
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt, csrf_protect

from .forms import SignupForm
from .models import Member


# Create your views here.
def agree(request):
    return render(request, 'member/agree.html')

@csrf_protect
def regist(request):
    if request.method == "GET":
        return HttpResponseRedirect("agree")
    elif request.method == "POST" :
        agree = request.POST.get("agree")
        if agree is not None :
            return render(request, 'member/memberForm.html',{'f':SignupForm()})
        else :
            return HttpResponseRedirect("agree")
        

@csrf_exempt
def memberJoinAction(request):
    if request.method == "GET":
        return HttpResponseRedirect("agree")
    elif request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            if form.cleaned_data['USER_PW']  == form.cleaned_data['USER_PW_Con']:
                member = Member()
                member.USER_ID = form.cleaned_data['USER_ID']
                member.USER_PW = form.cleaned_data['USER_PW']
                member.USER_NAME = form.cleaned_data['USER_NAME']
                member.USER_BIRTH = form.cleaned_data['USER_BIRTH']
                member.USER_GENDER = form.cleaned_data['USER_GENDER']
                member.USER_EMAIL = form.cleaned_data['USER_EMAIL']
                member.USER_ADDR = form.cleaned_data['USER_ADDR']
                member.USER_PH1 = form.cleaned_data['USER_PH1']
                member.USER_PH2 = form.cleaned_data['USER_PH2']
                member.USER_REGIST = datetime.now()
                try:
                    print("저장되었습니다.")
                    member.save()
                    return HttpResponseRedirect("/")
                except :
                   # return HttpResponseNotFound("가입되지 않았습니다.")
                    return render(request, 'member/memberForm.html',{'f':form,'error':'가입되지 않았습니다.'})    
            else :
                return render(request, 'member/memberForm.html',{'f':form,'error':'비밀번호 확인이  비밀번호와 다릅니다.'})
        else :
            return render(request, 'member/memberForm.html',{'f':form,'error':'가입되지 않았습니다.'})