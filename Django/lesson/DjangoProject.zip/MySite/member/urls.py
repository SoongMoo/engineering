from django.conf.urls import url

from . import views


app_name = 'member'
urlpatterns = [
    url('agree', views.agree),
    url('regist', views.regist),
    url('memberJoinAction', views.memberJoinAction),
]
