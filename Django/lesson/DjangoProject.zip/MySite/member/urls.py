from django.conf.urls import url

from . import views


app_name = 'member'
urlpatterns = [ 
    url('memberDrop/(?P<USER_ID>\w+)', views.memberDrop),
    url('memberUpdatePro', views.memberUpdatePro),
    url('memberUpdate', views.memberUpdate),
    url('memberInfo', views.memberInfo),
    url('memberlist', views.memberlist),
    url('memberDeletePro', views.memberDeletePro),
    url('memberDelete', views.memberDelete),
    url('memberPasswordModifyPro', views.memberPasswordModifyPro),
    url('memberPasswordPro', views.memberPasswordPro),
    url('changePassword', views.changePassword),
    url('memberModifyPro', views.memberModifyPro),
    url('memberModify', views.memberModify),
    url('memberDetail', views.memberDetail),
    url('memberMail/(?P<USER_CK>\w+)', views.memberMail),
    url('agree', views.agree),
    url('regist', views.regist),
    url('memberJoinAction', views.memberJoinAction),
    
]
