from django.conf.urls import url

from . import views

app_name = 'Main'
urlpatterns = [
    url('', views.index),
]
