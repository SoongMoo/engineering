from django.shortcuts import render

from django.http import HttpResponse

from .forms import SigninForm
# Create your views here.
def index(request):
    form = SigninForm(request.POST)
    return render(request , 'Main/main.html',{'f':form})
