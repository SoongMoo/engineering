from django.http import HttpResponse
from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from member.models import Member

from .forms import SigninForm


# Create your views here.
def index(request):
    form = SigninForm(request.POST)
    ## cookie가 있을 때
    ### 웨브라우저에 있는 쿠키를 가지고 옴.
    if request.COOKIES.get('idStore') is not None:
        context = {'idStore' : request.COOKIES.get('idStore')}
        form = SigninForm(initial={"USER_ID" :context['idStore'] })
        return render(request , 'Main/main.html',{'f':form, 'context':context})
    if request.COOKIES.get('autoLogin') is not None:
        member = Member.objects.get(USER_ID = request.COOKIES.get('autoLogin'))
        request.session['member'] = {} ## 정상적으로 로그인이 되었을 때 session을 생성
                                        ##session의 속성 ### 디비로부터 가지고 온 값 
        request.session['member']['USER_ID'] =  member.USER_ID
        request.session['member']['USER_PW'] =  member.USER_PW
        request.session['member']['USER_NAME'] =  member.USER_NAME
        request.session['member']['USER_EMAIL'] =  member.USER_EMAIL
    # cookie가 없을 때
    return render(request , 'Main/main.html',{'f':form})

@csrf_exempt
def loginAction(request):
    response = HttpResponseRedirect("/")
    if request.method == 'GET':
        return response
    elif request.method == 'POST':
        id1 = request.POST['USER_ID']
        pw = request.POST['USER_PW'] ## Django-ORM
        member = Member.objects.get(USER_ID = id1)
        if member is not None:
            if member.USER_CK == '':
                return render(request, 'Main/main.html', {'f':SigninForm(),'error':'가입하신 이메일에서 가입승인을 먼저해주세요.'})
            
            if member.USER_PW == pw:
                try:
                    print("로그인되었습니다.")
                    request.session['member'] = {} ## 정상적으로 로그인이 되었을 때 session을 생성
                                        ##session의 속성 ### 디비로부터 가지고 온 값 
                    request.session['member']['USER_ID'] =  member.USER_ID
                    request.session['member']['USER_PW'] =  member.USER_PW
                    request.session['member']['USER_NAME'] =  member.USER_NAME
                    request.session['member']['USER_EMAIL'] =  member.USER_EMAIL
                    max_age = 30*24*60*60
                    if request.POST.get('idStore') is not None:     
                        response.set_cookie('idStore', member.USER_ID, max_age = max_age)
                    else:
                        response.set_cookie('idStore', member.USER_ID, max_age = 0)
                    
                    if request.POST.get('autoLogin') is not None:
                        response.set_cookie('autoLogin', member.USER_ID, max_age = max_age)
                    
                    return response
                except:
                    print("로그인 되지 않았습니다.")
            else :
                print("비밀번호가 틀립니다.")
                return render(request, 'Main/main.html', {'f':SigninForm(), 'error':"비밀번호가 틀립니다."})
        else:
            return render(request, 'Main/main.html', {'f':SigninForm(), 'error':"아이디가 존재하지 않습니다."})        
        
def logout(request):
    response = HttpResponseRedirect("")
    try:
        response.set_cookie('autoLogin', '', max_age = 0)
        del request.session['member']
    except:
        pass
    return HttpResponseRedirect("/")








        
        
        
        