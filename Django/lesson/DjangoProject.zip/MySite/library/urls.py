from django.conf.urls import url 
from django.urls import path
from . import views

app_name = 'library'
urlpatterns = [
    url('libDel', views.libraryDelete),
    url('libModify', views.libraryModify),
    url('libUpdate', views.libraryUpdate),
    url('libDetail', views.libDetail),
    url('libWritePro', views.libraryWritePro),
    url('libWriteForm', views.libraryWriteForm),
    url('libList', views.libraryList),
]
