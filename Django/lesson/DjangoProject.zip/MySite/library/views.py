from _ast import Try
import math
import os
import uuid

from django.core.files.storage import FileSystemStorage
from django.core.paginator import Paginator
from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from MySite import settings
from member.models import Member
from member.views import pwEncrypt

from .forms import LibraryWriteForm
from .models import Library


# Create your views here.
def libraryList(request):
    librarys = Library.objects.all().order_by("-LIB_NUM")
    
    ################ paging #############
    page = request.GET.get('page',1)
    limit = 5
    page_range = 10 
    paginator = Paginator(librarys,limit )
    contacts = paginator.get_page(page)
    current_block = math.ceil(int(page)/page_range)
    start_block = (current_block -1) * page_range #  0, 10 , 20
    end_block = start_block + page_range
    p_range = paginator.page_range[start_block:end_block]
    context = {'contacts':contacts,'p_range':p_range}
    ################ paging #############
    
    return render(request, "library/libraryList.html", context);


def libraryDelete(request):
    library = Library.objects.get(LIB_NUM = request.GET['LIB_NUM'])
    if library.LIB_PASS == pwEncrypt(request.GET['LIB_PASS']):
        fileNames = library.LIB_STO_FILE.split(",")
        try:
            if library.LIB_STO_FILE is not None:
                for fileName in fileNames:
                    os.remove(os.path.join(settings.MEDIA_ROOT, fileName.path))
        except:
            pass
        library.delete()
        return HttpResponseRedirect("libList")
    else:
        context = {'library':library, 'error':'비밀번호가 틀렸습니다.'}
        return render(request, "library/libraryModify.html", context)
    

@csrf_exempt
def libraryModify(request):
    library = Library.objects.get(LIB_NUM = request.POST['LIB_NUM'])
    form = LibraryWriteForm(request.POST)
    if form.is_valid():
        if library.LIB_PASS == pwEncrypt(request.POST['LIB_PASS']):
            library.LIB_SUBJECT = request.POST['LIB_SUBJECT']
            library.LIB_CONTENT = request.POST['LIB_CONTENT']
            library.save()
            return HttpResponseRedirect("libDetail?LIB_NUM="+request.POST['LIB_NUM'])
        else:
            context = {'library':library, 'error':'비밀번호가 틀렸습니다.'}
            return render(request, "library/libraryModify.html",context)
    else:
        context = {'library':library, 'error':'비밀번호의 길이는 8자리입니다.'}
        return render(request, "library/libraryModify.html",context)
        
def libraryUpdate(request):
    library = Library.objects.get(LIB_NUM = request.GET['LIB_NUM'])
    
    ###############################################################
    fileNames = library.LIB_ORG_FILE.split(",")
    storefileNames = library.LIB_STO_FILE.split(",")
    fileSizes = library.LIB_FILE_SIZE.split(",")
    file_results = []
    for index, value in enumerate(fileNames):
        result = {}
        result['fileName'] = value
        result['storefileName'] = storefileNames[index]
        result['fileSize'] = fileSizes[index]
        print(result)
        file_results.append(result)
    print(len(file_results))
    context = {'library':library, 'file_results':file_results}
    ##################################################################
    # context = {'library':library}
    return render(request, "library/libraryModify.html", context)

def libDetail(request):
    library = Library.objects.get(LIB_NUM = request.GET['LIB_NUM'])
    library.LIB_READCOUNT += 1
    library.save()
    ###############################################################
    fileNames = library.LIB_ORG_FILE.split(",")
    storefileNames = library.LIB_STO_FILE.split(",")
    fileSizes = library.LIB_FILE_SIZE.split(",")
    file_results = []
    for index, value in enumerate(fileNames):
        result = {}
        result['fileName'] = value
        result['storefileName'] = storefileNames[index]
        result['fileSize'] = fileSizes[index]
        print(result)
        file_results.append(result)
    print(len(file_results))
    context = {'lib':library, 'file_results':file_results}
    ##################################################################
    # context = {'lib':library}
    return render(request, "library/libraryDetail.html",context)


def libraryWriteForm(request):
    return render(request, "library/libraryForm.html",{'f':LibraryWriteForm()})

@csrf_exempt
def libraryWritePro(request):
    member = Member.objects.get(USER_ID = request.session['member']['USER_ID'])
    
    form = LibraryWriteForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            library = Library()
            #######################################################################
            fs = FileSystemStorage(location='../MySite/media/uploads/')
            myfiles = request.FILES.getlist('BOARD_STORE_FILENAME')
            print(len(myfiles))
            fileNames = ""   # 시스템에 저장되는 파일명 
            fileSize = ""    # 파일의 사이즈
            originalName=""  # upload할 때의 파일명
            for myfile in myfiles:
                ### ../static/media/uploads/파일명을 시스템에 저장
                file = fs.save(myfile.name, myfile) 
                fileSize += str(os.path.getsize("../MySite/media/uploads/" + file)) +","
                #### 파일의 확장자를 가져오기
                extension = file.rsplit('.', 1)[1]   ### 브렌드 선정.hwp ['브렌드 선정','hwp']    
                ### 파일명을 생성
                fileName = uuid.uuid4().__str__().replace('-', '') + "." + extension
                os.rename('../MySite/media/uploads/' + file, 
                          '../MySite/media/uploads/' + fileName)    
                fileNames += fileName + ","
                originalName += file + ","
                
            ### 디비에 저장
            library.LIB_STO_FILE = fileNames
            library.LIB_ORG_FILE = originalName
            library.LIB_FILE_SIZE = fileSize
            #################################################################################
            library.LIB_CONTENT = request.POST['LIB_CONTENT']
            library.LIB_SUBJECT = request.POST['LIB_SUBJECT']
            library.LIB_PASS = pwEncrypt(request.POST['LIB_PASS'])
            library.USER_ID = member
            library.save()
            return HttpResponseRedirect("libList")
        else:
            return render(request, "library/libraryForm.html",{'f':LibraryWriteForm(),
                                                               'error':'비밀번호는 8자입니다.'})
    else:
        return render(request, "library/libraryForm.html",{'f':form})
    
    