import math

from django.core.paginator import Paginator
from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from member.models import Member
from member.views import pwEncrypt

from .forms import LibraryWriteForm
from .models import Library


# Create your views here.
def libraryList(request):
    librarys = Library.objects.all().order_by("-LIB_NUM")
    
    ################ paging #############
    page = request.GET.get('page',1)
    limit = 5
    page_range = 10 
    paginator = Paginator(librarys,limit )
    contacts = paginator.get_page(page)
    current_block = math.ceil(int(page)/page_range)
    start_block = (current_block -1) * page_range #  0, 10 , 20
    end_block = start_block + page_range
    p_range = paginator.page_range[start_block:end_block]
    context = {'contacts':contacts,'p_range':p_range}
    ################ paging #############
    
    return render(request, "library/libraryList.html", context);

def libraryDelete(request):
    library = Library.objects.get(LIB_NUM = request.GET['LIB_NUM'])
    if library.LIB_PASS == pwEncrypt(request.GET['LIB_PASS']):
        library.delete()
        return HttpResponseRedirect("libList")
    else:
        context = {'library':library, 'error':'비밀번호가 틀렸습니다.'}
        return render(request, "library/libraryModify.html", context)
    

@csrf_exempt
def libraryModify(request):
    library = Library.objects.get(LIB_NUM = request.POST['LIB_NUM'])
    form = LibraryWriteForm(request.POST)
    if form.is_valid():
        if library.LIB_PASS == pwEncrypt(request.POST['LIB_PASS']):
            library.LIB_SUBJECT = request.POST['LIB_SUBJECT']
            library.LIB_CONTENT = request.POST['LIB_CONTENT']
            library.save()
            return HttpResponseRedirect("libDetail?LIB_NUM="+request.POST['LIB_NUM'])
        else:
            context = {'library':library, 'error':'비밀번호가 틀렸습니다.'}
            return render(request, "library/libraryModify.html",context)
    else:
        context = {'library':library, 'error':'비밀번호의 길이는 8자리입니다.'}
        return render(request, "library/libraryModify.html",context)
        
def libraryUpdate(request):
    library = Library.objects.get(LIB_NUM = request.GET['LIB_NUM'])
    return render(request, "library/libraryModify.html",{'library':library})

def libDetail(request):
    library = Library.objects.get(LIB_NUM = request.GET['LIB_NUM'])
    library.LIB_READCOUNT += 1
    library.save()
    return render(request, "library/libraryDetail.html",{'lib':library})


def libraryWriteForm(request):
    return render(request, "library/libraryForm.html",{'f':LibraryWriteForm()})

@csrf_exempt
def libraryWritePro(request):
    member = Member.objects.get(USER_ID = request.session['member']['USER_ID'])
    
    form = LibraryWriteForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            library = Library()
            library.LIB_CONTENT = request.POST['LIB_CONTENT']
            library.LIB_SUBJECT = request.POST['LIB_SUBJECT']
            library.LIB_PASS = pwEncrypt(request.POST['LIB_PASS'])
            library.USER_ID = member
            library.save()
            return HttpResponseRedirect("libList")
        else:
            return render(request, "library/libraryForm.html",{'f':LibraryWriteForm(),
                                                               'error':'비밀번호는 8자입니다.'})
    else:
        return render(request, "library/libraryForm.html",{'f':form})
    
    