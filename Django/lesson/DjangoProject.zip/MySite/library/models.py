from datetime import datetime
import os

from django.core.validators import MinLengthValidator
from django.db import models

from MySite import settings
from member.models import Member


# Create your models here.
class Library(models.Model):
    pw_validator = MinLengthValidator(8, MinLengthValidator)
    USER_ID = models.ForeignKey(Member, on_delete=models.CASCADE    )
    LIB_NUM = models.BigAutoField(blank=False, null=False, primary_key=True)
    LIB_SUBJECT = models.CharField(max_length=50, blank=False, null=False)
    LIB_CONTENT = models.CharField(max_length=2000, blank=False, null=False)
    LIB_PASS = models.CharField(max_length=200, blank=False, null=False,
                                validators=[pw_validator])
    LIB_READCOUNT = models.DecimalField(max_digits=6, decimal_places= 0, default= 0,
                                          blank=False, null=False )
    LIB_DATE = models.DateTimeField(blank=False, null=False, default=datetime.now)
    
    #########################  자료실  ######################################
    LIB_ORG_FILE = models.CharField(max_length=200, blank=False, null=True)
    LIB_STO_FILE = models.CharField(max_length=200, blank=False, null=True)
    LIB_FILE_SIZE = models.CharField(max_length=200, blank=False, null=True)
    ########################################################################
    
    def delete(self, *args, **kargs):
        fileNames = self.LIB_STO_FILE.split(",")
        for index, value in enumerate(fileNames):
            print(value)
            if value is not "":
                os.remove(os.path.join(settings.MEDIA_ROOT+"\\uploads\\",value))
        super(Library, self).delete(*args, **kargs)
    
    class Meta:
        db_table = 'LIBRARY'