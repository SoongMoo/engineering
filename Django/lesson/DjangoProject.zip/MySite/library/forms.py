'''
Created on 2021. 7. 29.

@author: EZEN
'''
from django import forms
from django.forms.models import ModelForm

from .models import Library
from django.utils.translation import gettext as _


class LibraryWriteForm(ModelForm):
    BOARD_STORE_FILENAME = forms.FileField(label = '등록 할 파일', required=False,
                        widget=forms.ClearableFileInput(attrs={'multiple': True}))
    class Meta:
        model = Library
        widgets = {'LIB_PASS': forms.PasswordInput ,'LIB_CONTENT':forms.Textarea}
        fields = ['LIB_SUBJECT','LIB_CONTENT','LIB_PASS', 'BOARD_STORE_FILENAME']
        labels = {
            'LIB_SUBJECT':_('제목'),
            'LIB_CONTENT':_('내용'),
            'LIB_PASS':_('비밀번호'),
            }
